**Please provide the following information**

### qBittorrent version and Operating System
(type here)

### If on linux, libtorrent-rasterbar and Qt version
(type here)

### What is the problem
(type here)

### What is the expected behavior
(type here)

### Steps to reproduce
(type here)

### Extra info(if any)
(type here)

